classdef DiceGameENG6Core < matlab.apps.AppBase

    % Properties that correspond to app components
    properties (Access = public)
        UIFigure                      matlab.ui.Figure
        dice2_6                       matlab.ui.control.Image
        dice2_5                       matlab.ui.control.Image
        dice2_4                       matlab.ui.control.Image
        dice2_3                       matlab.ui.control.Image
        dice2_2                       matlab.ui.control.Image
        dice2_1                       matlab.ui.control.Image
        dice1_6                       matlab.ui.control.Image
        dice1_5                       matlab.ui.control.Image
        dice1_4                       matlab.ui.control.Image
        dice1_3                       matlab.ui.control.Image
        dice1_2                       matlab.ui.control.Image
        dice1_1                       matlab.ui.control.Image
        RoundWinnerLabel              matlab.ui.control.Label
        MessageLabel                  matlab.ui.control.Label
        Dice2Label                    matlab.ui.control.Label
        Dice1Label                    matlab.ui.control.Label
        NewRoundButton                matlab.ui.control.Button
        NewGameButton                 matlab.ui.control.Button
        DealerStandingUI              matlab.ui.control.NumericEditField
        DealerStandingEditFieldLabel  matlab.ui.control.Label
        PlayerStandingUI              matlab.ui.control.NumericEditField
        PlayerStandingEditFieldLabel  matlab.ui.control.Label
        DealerTotalUI                 matlab.ui.control.NumericEditField
        DealerTotalEditFieldLabel     matlab.ui.control.Label
        PlayerTotalUI                 matlab.ui.control.NumericEditField
        PlayerTotalEditFieldLabel     matlab.ui.control.Label
        SelectButton                  matlab.ui.control.Button
        DiceValueButtonGroup          matlab.ui.container.ButtonGroup
        BottomDiceButton              matlab.ui.control.RadioButton
        TopDiceButton                 matlab.ui.control.RadioButton
        SumofDiceButton               matlab.ui.control.RadioButton
        StartButton                   matlab.ui.control.Button
        RoleButtonGroup               matlab.ui.container.ButtonGroup
        DealerButton                  matlab.ui.control.RadioButton
        PlayerButton                  matlab.ui.control.RadioButton
        StandButton                   matlab.ui.control.Button
        HitButton                     matlab.ui.control.Button
    end

    
   properties (Access = public)
        % thingSpeak Channel ID and Keys
        channelID = 2976444;
        writeKey = '7D4W0J88D5Z76I9N'; 
        readKey = 'GX2EPQWYTSLNY04C'; 
        
        myPlayerNum % 1 for player, 2 for dealer
        
        % game state vars
        dice1 
        dice2 
        
        playerStanding_TS = 0;
        dealerStanding_TS = 0;
        playerGameScore_TS = 0;
        dealerGameScore_TS = 0;
        turnAndAction_TS = 0; 
        gameStatus_TS = 0;  
        playerStoodAndDealerStood_TS = 0; 
        diceValues_TS = 0;  

        % local game state vars 
        whoseTurn = 0; 
        action = 0; % turns 1 for hit, otherwise 0
        gameEnded = false; % true if round is over
        overallGameEnded = false; % true when someone wins
        playerStood = false;
        dealerStood = false;
        
        
        writeDelay = 15;
        readDelay = 1;  

        
        dice1Images 
        dice2Images 

        audioClickPlayer
        audioDiceRollPlayer
        audioWaitingPlayer
        audioWinRoundPlayer
        audioWinGamePlayer
        audioLoseRoundPlayer 
        audioPath
    end
    
    methods (Access = private)

        function playSoundEffect(app, playerObject)
            if ~isempty(playerObject) && isvalid(playerObject)
                    stop(playerObject); 
                    play(playerObject);

            end
        end
        
        function [] = ClearThingSpeakChannel(app)
            app.MessageLabel.Text = 'Clearing game channel... Please wait.';
            drawnow;
            app.playSoundEffect(app.audioWaitingPlayer);
            pause(app.writeDelay); 
            thingSpeakWrite(app.channelID, 'Fields', 1:8, 'Values', zeros(1,8), 'WriteKey', app.writeKey);
            fprintf('ThingSpeak channel cleared.\n');
            app.MessageLabel.Text = 'Channel cleared. Select role to start.';
            drawnow;
        end
        
        function SendDataToOtherPlayer(app)
            
            app.turnAndAction_TS = (app.whoseTurn * 10) + app.action;
            app.gameStatus_TS = (double(app.gameEnded) * 1) + (double(app.overallGameEnded) * 2);
            app.playerStoodAndDealerStood_TS = (double(app.playerStood) * 1) + (double(app.dealerStood) * 2);
            
            if isempty(app.dice1) || isnan(app.dice1), app.dice1 = 0; end
            if isempty(app.dice2) || isnan(app.dice2), app.dice2 = 0; end
            app.diceValues_TS = (10 * app.dice1) + app.dice2;

            dataToSend = [app.playerStanding_TS, app.dealerStanding_TS, app.playerGameScore_TS, ...
                          app.dealerGameScore_TS, app.turnAndAction_TS, app.gameStatus_TS, ...
                          app.playerStoodAndDealerStood_TS, app.diceValues_TS];

            app.playSoundEffect(app.audioWaitingPlayer);
            pause(app.writeDelay); 
            thingSpeakWrite(app.channelID, 'Fields', 1:8, 'Values', dataToSend, 'WriteKey', app.writeKey);
            fprintf('Data sent to ThingSpeak: %s\n', mat2str(dataToSend));
    
        end
        
        function WaitForOtherPlayer(app)
            app.MessageLabel.Text = 'Waiting for other player''s move...';
            app.setControlsEnabled(false); 
            drawnow;

            while true 
                pause(app.readDelay);
                
                dataTable = thingSpeakRead(app.channelID, 'Fields', 1:8, 'ReadKey', app.readKey, 'OutputFormat', 'table', 'NumPoints', 1);
                
                if isempty(dataTable) || height(dataTable) < 1
                   
                    continue;
                end
                
                
                new_playerStanding_TS = dataTable{1, 2}; 
                new_dealerStanding_TS = dataTable{1, 3}; 
                new_playerGameScore_TS = dataTable{1, 4}; 
                new_dealerGameScore_TS = dataTable{1, 5}; 
                new_turnAndAction_TS = dataTable{1, 6}; 
                new_gameStatus_TS = dataTable{1, 7};    
                new_playerStoodAndDealerStood_TS = dataTable{1, 8}; 
                new_diceValues_TS = dataTable{1, 9};   

                
                isNewData = ~(app.playerStanding_TS == new_playerStanding_TS && ...
                              app.dealerStanding_TS == new_dealerStanding_TS && ...
                              app.turnAndAction_TS == new_turnAndAction_TS && ...
                              app.gameStatus_TS == new_gameStatus_TS && ...
                              app.playerStoodAndDealerStood_TS == new_playerStoodAndDealerStood_TS && ...
                              app.diceValues_TS == new_diceValues_TS);

                if ~isNewData && app.whoseTurn ~= app.myPlayerNum 
                end

                app.playerStanding_TS = new_playerStanding_TS;
                app.dealerStanding_TS = new_dealerStanding_TS;
                app.playerGameScore_TS = new_playerGameScore_TS;
                app.dealerGameScore_TS = new_dealerGameScore_TS;
                app.turnAndAction_TS = new_turnAndAction_TS;
                app.gameStatus_TS = new_gameStatus_TS;
                app.playerStoodAndDealerStood_TS = new_playerStoodAndDealerStood_TS;
                app.diceValues_TS = new_diceValues_TS;
                
                %decoding receieved state
                app.whoseTurn = floor(app.turnAndAction_TS / 10);
                app.action = mod(app.turnAndAction_TS, 10);
                app.overallGameEnded = (app.gameStatus_TS >= 2); 
                app.gameEnded = (mod(app.gameStatus_TS, 2) == 1 || app.overallGameEnded);
                app.playerStood = (mod(app.playerStoodAndDealerStood_TS, 2) == 1);
                app.dealerStood = (app.playerStoodAndDealerStood_TS >= 2);
                app.dice1 = floor(app.diceValues_TS / 10);
                app.dice2 = mod(app.diceValues_TS, 10);
                
                fprintf('Data received: PlayerStand=%d, DealerStand=%d, PScore=%d, DScore=%d, TurnAct=%d, GameStat=%d, StoodStat=%d, DiceVal=%d\n', ...
                        app.playerStanding_TS, app.dealerStanding_TS, app.playerGameScore_TS, app.dealerGameScore_TS, ...
                        app.turnAndAction_TS, app.gameStatus_TS, app.playerStoodAndDealerStood_TS, app.diceValues_TS);
                fprintf('Decoded: WhoseTurn=%d, Action=%d, GameEnded=%d, OverallGameEnded=%d, PlayerStood=%d, DealerStood=%d\n', ...
                        app.whoseTurn, app.action, app.gameEnded, app.overallGameEnded, app.playerStood, app.dealerStood);

                app.UpdateStatus(); 

                if app.dice1 > 0 || app.dice2 > 0 
                    app.Dice1Label.Text = sprintf('Dice 1: %d', app.dice1);
                    app.Dice2Label.Text = sprintf('Dice 2: %d', app.dice2);
                    app.updateDiceImages(app.dice1, app.dice2);
                else 
                    app.Dice1Label.Text = 'Dice 1: -';
                    app.Dice2Label.Text = 'Dice 2: -';
                    app.updateDiceImages(0,0); 
                end
                drawnow;
                
                if app.overallGameEnded
                    app.handleOverallGameEnd(); 
                    return; 
                end
                
               
                if app.gameEnded 
                    app.MessageLabel.Text = 'Round ended. Click New Round or New Game.';
                    app.setControlsEnabled(false); 
                    return;
                end

                
                if app.myPlayerNum == app.whoseTurn && ~app.gameEnded
                    app.MessageLabel.Text = 'It''s your turn! Click Hit or Stand.';
                    if app.action == 1 
                        app.MessageLabel.Text = sprintf('Opponent rolled %d & %d. Your turn!', app.dice1, app.dice2);
                    elseif (app.myPlayerNum == 1 && app.dealerStood)
                        app.MessageLabel.Text = 'Dealer stood. Your turn (Player)!';
                    elseif (app.myPlayerNum == 2 && app.playerStood)
                        app.MessageLabel.Text = 'Player stood. Your turn (Dealer)!';
                    end
                    app.setControlsEnabled(true); 
                    drawnow;
                    break; 
                else
                    app.MessageLabel.Text = 'Waiting for other player''s move...'; 
                    drawnow;
                end
            end
        end

        function InitialRetrieveData(app)
            
            app.MessageLabel.Text = 'Connecting to game... Waiting for Dealer''s first move.';
            app.setControlsEnabled(false);
            drawnow;
            
            app.WaitForOtherPlayer(); 
        end
        
        function UpdateStatus(app)
            app.PlayerStandingUI.Value = app.playerStanding_TS;
            app.DealerStandingUI.Value = app.dealerStanding_TS;
            app.PlayerTotalUI.Value = app.playerGameScore_TS; 
            app.DealerTotalUI.Value = app.dealerGameScore_TS; 
        end

        function setControlsEnabled(app, enable)
            if enable && app.myPlayerNum == app.whoseTurn && ~app.gameEnded && ~app.overallGameEnded
                enableStr = 'on';
            else
                enableStr = 'off';
            end

            app.HitButton.Enable = enableStr;
            app.StandButton.Enable = enableStr;
            
            
            if ~strcmp(enableStr, 'on') 
                app.SelectButton.Enable = 'off'; 
                app.SumofDiceButton.Enable = 'off';
                app.TopDiceButton.Enable = 'off';
                app.BottomDiceButton.Enable = 'off';
            end
            
            
            if app.gameEnded && ~app.overallGameEnded
                app.NewRoundButton.Enable = 'on';
            else
                app.NewRoundButton.Enable = 'off';
            end

            if app.overallGameEnded
                app.NewGameButton.Enable = 'on';
                app.NewRoundButton.Enable = 'off'; 
            
            end
        end

        function [roll1, roll2] = performDiceRoll(app)
            roll1 = randi(6);
            roll2 = randi(6);
            app.dice1 = roll1; 
            app.dice2 = roll2; 
        end

        function animateDiceRoll(app)
            app.playSoundEffect(app.audioDiceRollPlayer); 
            app.MessageLabel.Text = 'Rolling...';
            
            
            drawnow; 

            animationDuration = 0.7;
            flashDelay = 0.06;    
            numFlashes = floor(animationDuration / flashDelay);

            for k = 1:numFlashes
                for i = 1:6
                    app.dice1Images{i}.Visible = 'off';
                    app.dice2Images{i}.Visible = 'off';
                end
                randIdx1 = randi(6);
                randIdx2 = randi(6);
                app.dice1Images{randIdx1}.Visible = 'on';
                app.dice2Images{randIdx2}.Visible = 'on';
                drawnow; 
                pause(flashDelay);
            end

            for i = 1:6
                app.dice1Images{i}.Visible = 'off';
                app.dice2Images{i}.Visible = 'off';
            end
            drawnow; 
        end

        function updateDiceImages(app, roll1, roll2)
            for i = 1:6
                app.dice1Images{i}.Visible = 'off';
                app.dice2Images{i}.Visible = 'off';
            end
            if roll1 >= 1 && roll1 <= 6
                app.dice1Images{roll1}.Visible = 'on';
            end
            if roll2 >= 1 && roll2 <= 6
                app.dice2Images{roll2}.Visible = 'on';
            end
            drawnow; 
        end

        function [newStanding] = applyDiceValue(app, currentStanding, r1, r2, selection)
            newStanding = currentStanding;
            switch selection
                case 'Sum of Dice'
                    newStanding = newStanding + (r1 + r2);
                case 'Top Dice' 
                    newStanding = newStanding + r1;
                case 'Bottom Dice' 
                    newStanding = newStanding + r2;
            end
        end

        function determineRoundWinner(app, pStanding, dStanding)
           
            app.gameEnded = true; 
            winnerMessage = '';
            playerWonRound = false; 
            dealerWonRound = false;
            
            playerBusted = pStanding > 21;
            dealerBusted = dStanding > 21;

            if playerBusted && dealerBusted
                winnerMessage = 'Both busted! Round is a tie.';
            elseif playerBusted
                winnerMessage = sprintf('Player busted with %d! Dealer wins round.', pStanding);
                app.dealerGameScore_TS = app.dealerGameScore_TS + 1;
                dealerWonRound = true;
            elseif dealerBusted
                winnerMessage = sprintf('Dealer busted with %d! Player wins round.', dStanding);
                app.playerGameScore_TS = app.playerGameScore_TS + 1;
                playerWonRound = true;
            elseif pStanding == dStanding
                winnerMessage = sprintf('Both stood at %d. Round is a tie!', pStanding);
            elseif pStanding > dStanding
                winnerMessage = sprintf('Player wins round with %d vs %d!', pStanding, dStanding);
                app.playerGameScore_TS = app.playerGameScore_TS + 1;
                playerWonRound = true;
            else 
                winnerMessage = sprintf('Dealer wins round with %d vs %d!', dStanding, pStanding);
                app.dealerGameScore_TS = app.dealerGameScore_TS + 1;
                dealerWonRound = true;
            end
            
            app.RoundWinnerLabel.Text = winnerMessage;
            app.MessageLabel.Text = 'Round Over! Sending final round state...';
            app.UpdateStatus(); 
            drawnow;

            if (app.myPlayerNum == 1 && playerWonRound) || (app.myPlayerNum == 2 && dealerWonRound)
                app.playSoundEffect(app.audioWinRoundPlayer);
            elseif (app.myPlayerNum == 1 && dealerWonRound) || (app.myPlayerNum == 2 && playerWonRound)
                app.playSoundEffect(app.audioLoseRoundPlayer); 
            end

            
            if app.playerGameScore_TS >= 5 || app.dealerGameScore_TS >= 5
                app.overallGameEnded = true;
                
            end
            
            
            app.setControlsEnabled(false); 
            app.SendDataToOtherPlayer(); 

            if app.overallGameEnded
                app.handleOverallGameEnd(); 
            else
                app.MessageLabel.Text = [winnerMessage, ' Click New Round.'];
                app.NewRoundButton.Enable = 'on'; 
                drawnow;
            end
        end

        function handleOverallGameEnd(app)
            
            app.overallGameEnded = true; 
            app.gameEnded = true; 
            
            finalMessage = '';
            playerWonGame = app.playerGameScore_TS >= 5;
            dealerWonGame = app.dealerGameScore_TS >= 5;

            if playerWonGame
                finalMessage = 'GAME OVER! Player wins the game!';
            elseif dealerWonGame
                finalMessage = 'GAME OVER! Dealer wins the game!';
            else
                finalMessage = 'GAME OVER!'; 
            end
            
            app.MessageLabel.Text = finalMessage;
            app.RoundWinnerLabel.Text = ''; 
            drawnow;

            if (app.myPlayerNum == 1 && playerWonGame) || (app.myPlayerNum == 2 && dealerWonGame)
                app.playSoundEffect(app.audioWinGamePlayer);
            elseif (app.myPlayerNum == 1 && dealerWonGame) || (app.myPlayerNum == 2 && playerWonGame)
                 app.playSoundEffect(app.audioLoseRoundPlayer);
            end
            
            
            app.setControlsEnabled(false); 
            app.NewGameButton.Enable = 'on'; 
            app.NewRoundButton.Enable = 'off';
            
        end

        function startNewRound(app)
            app.playSoundEffect(app.audioClickPlayer);
            app.MessageLabel.Text = 'Starting new round... Please wait.';
            app.setControlsEnabled(false); 
            drawnow;

            
            app.playerStanding_TS = 0;
            app.dealerStanding_TS = 0;
         
            app.action = 0; 
            app.dice1 = 0;
            app.dice2 = 0;
            app.gameEnded = false;
           
            app.playerStood = false; 
            app.dealerStood = false; 
            
            app.updateDiceImages(0,0); 
            app.Dice1Label.Text = 'Dice 1: -';
            app.Dice2Label.Text = 'Dice 2: -';
            app.RoundWinnerLabel.Text = '';
            app.UpdateStatus();
            drawnow;

          
            if app.myPlayerNum == 2
                app.MessageLabel.Text = 'Your turn (Dealer)! Performing initial roll for new round...';
                app.setControlsEnabled(false); 
                drawnow;

                app.animateDiceRoll(); 
                [roll1, roll2] = app.performDiceRoll();
                app.Dice1Label.Text = sprintf('Dice 1: %d', roll1); 
                app.Dice2Label.Text = sprintf('Dice 2: %d', roll2); 
                app.updateDiceImages(roll1, roll2); 

                [newStanding] = app.applyDiceValue(0, roll1, roll2, 'Sum of Dice'); 
                app.dealerStanding_TS = newStanding;
                app.UpdateStatus(); 
                
                app.whoseTurn = 1; 
                app.action = 0; 
                
                app.MessageLabel.Text = 'Sending initial round state... Please wait.';
                drawnow;
                app.SendDataToOtherPlayer(); 
                
                app.MessageLabel.Text = sprintf('Dealer initially rolled for %d. Waiting for Player.', app.dealerStanding_TS);
                drawnow;
                app.WaitForOtherPlayer();
            else
                app.MessageLabel.Text = 'New round. Waiting for Dealer''s initial move...';
                drawnow;
                
                app.whoseTurn = 2; 
                app.action = 0;
                app.WaitForOtherPlayer(); 
            end
        end

        function resetGame(app)
            app.playSoundEffect(app.audioClickPlayer);
            app.MessageLabel.Text = 'Resetting game... Please wait.';
            app.setControlsEnabled(false);
            drawnow;

            app.playerGameScore_TS = 0;
            app.dealerGameScore_TS = 0;
            app.playerStanding_TS = 0;
            app.dealerStanding_TS = 0;
            app.whoseTurn = 0;
            app.action = 0;
            app.dice1 = 0;
            app.dice2 = 0;
            app.gameEnded = false; 
            app.overallGameEnded = false; 
            app.playerStood = false;
            app.dealerStood = false;
            
            app.UpdateStatus(); 
            app.updateDiceImages(0,0);
            app.Dice1Label.Text = 'Dice 1: -';
            app.Dice2Label.Text = 'Dice 2: -';
            app.RoundWinnerLabel.Text = '';
            
            set(app.RoleButtonGroup, 'Visible', 'on'); 
            set(app.StartButton, 'Visible', 'on'); 
            app.StartButton.Enable = 'on'; 
            
            
            set(app.NewGameButton, 'Enable', 'off'); 
            set(app.NewRoundButton, 'Enable', 'off');
            
            app.ClearThingSpeakChannel(); 
           
            drawnow;
        end
    end
    

    % Callbacks that handle component events
    methods (Access = private)

        % Code that executes after component creation
        function startupFcn(app)
            app.audioPath = fullfile(fileparts(mfilename('fullpath')), 'audioFiles');
            
            [y, Fs] = audioread(fullfile(app.audioPath, 'click.wav')); 
            app.audioClickPlayer = audioplayer(y, Fs);
            [y, Fs] = audioread(fullfile(app.audioPath, 'dice.wav')); 
            app.audioDiceRollPlayer = audioplayer(y, Fs);
            [y, Fs] = audioread(fullfile(app.audioPath, 'wait.wav')); 
            app.audioWaitingPlayer = audioplayer(y, Fs);
            [y, Fs] = audioread(fullfile(app.audioPath, 'win.wav')); 
            app.audioWinRoundPlayer = audioplayer(y, Fs);
            [y, Fs] = audioread(fullfile(app.audioPath, 'win.wav')); 
            app.audioWinGamePlayer = audioplayer(y, Fs);

            app.dice1Images = {app.dice1_1, app.dice1_2, app.dice1_3, app.dice1_4, app.dice1_5, app.dice1_6};
            app.dice2Images = {app.dice2_1, app.dice2_2, app.dice2_3, app.dice2_4, app.dice2_5, app.dice2_6};

            for i = 1:6
                app.dice1Images{i}.Visible = 'off';
                app.dice2Images{i}.Visible = 'off';
            end

            app.setControlsEnabled(false); 
            set(app.RoleButtonGroup, 'Visible', 'on'); 
            set(app.StartButton, 'Visible', 'on');    
            set(app.StartButton, 'Enable', 'on');     
            set(app.NewRoundButton, 'Visible', 'on'); 
            set(app.NewRoundButton, 'Enable', 'off');
            set(app.NewGameButton, 'Visible', 'on');
            set(app.NewGameButton, 'Enable', 'off'); 
            
            app.Dice1Label.Text = 'Dice 1: -';
            app.Dice2Label.Text = 'Dice 2: -';
            app.RoundWinnerLabel.Text = '';
            app.MessageLabel.Text = 'Welcome! Select your role and click Start.';
            
            app.UpdateStatus(); 
            app.ClearThingSpeakChannel();
        end

        % Button pushed function: StartButton
        function StartButtonPushed(app, event)
            app.playSoundEffect(app.audioClickPlayer);
            
            if strcmp(app.RoleButtonGroup.SelectedObject.Text, 'Player')
                app.myPlayerNum = 1;
            else 
                app.myPlayerNum = 2;
            end
            
            app.playerStanding_TS = 0; app.dealerStanding_TS = 0;
            app.playerGameScore_TS = 0; app.dealerGameScore_TS = 0;
            app.action = 0; 
            app.gameEnded = false; app.overallGameEnded = false;
            app.playerStood = false; app.dealerStood = false; 
            app.dice1=0; app.dice2=0;
            
            set(app.RoleButtonGroup, 'Visible', 'off'); 
            set(app.StartButton, 'Enable', 'off'); 
            app.setControlsEnabled(false); 
            
            app.UpdateStatus(); 
            app.updateDiceImages(0,0); 
            app.Dice1Label.Text = 'Dice 1: -';
            app.Dice2Label.Text = 'Dice 2: -';
            app.RoundWinnerLabel.Text = '';
            drawnow;

            if app.myPlayerNum == 2 
                app.MessageLabel.Text = 'Your turn (Dealer)! Performing initial roll...';
                drawnow;
                
                app.animateDiceRoll(); 
                [roll1, roll2] = app.performDiceRoll();
                app.Dice1Label.Text = sprintf('Dice 1: %d', roll1); 
                app.Dice2Label.Text = sprintf('Dice 2: %d', roll2); 
                app.updateDiceImages(roll1, roll2); 

                [newStanding] = app.applyDiceValue(0, roll1, roll2, 'Sum of Dice'); 
                app.dealerStanding_TS = newStanding;
                app.UpdateStatus(); 
                
                app.whoseTurn = 1; 
                app.action = 0;
                
                app.MessageLabel.Text = 'Sending initial game state... Please wait.';
                drawnow;
                app.SendDataToOtherPlayer(); 
                
                app.MessageLabel.Text = sprintf('Dealer initially rolled for %d. Waiting for Player.', app.dealerStanding_TS);
                drawnow;
                app.WaitForOtherPlayer(); 
            else
                app.whoseTurn = 2; 
                app.action = 0;
                
                app.MessageLabel.Text = 'Waiting for Dealer''s initial setup...';
                drawnow;
                app.InitialRetrieveData(); 
            end
        end

        % Button pushed function: HitButton
        function HitButtonPushed(app, event)
            app.playSoundEffect(app.audioClickPlayer);
            if app.gameEnded || app.overallGameEnded || app.myPlayerNum ~= app.whoseTurn
                return; 
            end
            
            app.setControlsEnabled(false); 
            app.MessageLabel.Text = 'Rolling...';
            drawnow;

            app.animateDiceRoll(); 
            [roll1, roll2] = app.performDiceRoll(); 
            app.Dice1Label.Text = sprintf('Dice 1: %d', roll1); 
            app.Dice2Label.Text = sprintf('Dice 2: %d', roll2); 
            app.updateDiceImages(roll1, roll2); 
           
            app.SelectButton.Enable = 'on';
            currentStanding = 0;
            if app.myPlayerNum == 1 
                currentStanding = app.playerStanding_TS;
            else 
                currentStanding = app.dealerStanding_TS;
            end

            if currentStanding >= 16
                set(app.SumofDiceButton,'Enable','on');
                set(app.TopDiceButton,'Enable','on');
                set(app.BottomDiceButton,'Enable','on');
            else
                set(app.SumofDiceButton,'Enable','on');
                set(app.TopDiceButton,'Enable','off');
                set(app.BottomDiceButton,'Enable','off');
                app.DiceValueButtonGroup.SelectedObject = app.SumofDiceButton; 
            end
            app.MessageLabel.Text = sprintf('You rolled %d & %d. Choose value to use.', roll1, roll2);
            
            
            app.action = 1; 
            
            drawnow;
        end

        % Button pushed function: SelectButton
        function SelectButtonPushed(app, event)
            app.playSoundEffect(app.audioClickPlayer);
            if app.gameEnded || app.overallGameEnded || app.myPlayerNum ~= app.whoseTurn
                return; 
            end

            app.setControlsEnabled(false); 
            app.SelectButton.Enable = 'off'; 
            app.SumofDiceButton.Enable = 'off';
            app.TopDiceButton.Enable = 'off';
            app.BottomDiceButton.Enable = 'off';
            drawnow;
            
            currentSelection = app.DiceValueButtonGroup.SelectedObject.Text;
            newStanding = 0;

            if app.myPlayerNum == 1 
                newStanding = app.applyDiceValue(app.playerStanding_TS, app.dice1, app.dice2, currentSelection);
                app.playerStanding_TS = newStanding;
            else 
                newStanding = app.applyDiceValue(app.dealerStanding_TS, app.dice1, app.dice2, currentSelection);
                app.dealerStanding_TS = newStanding;
            end
            
            app.UpdateStatus(); 
            app.action = 1; 

            busted = (app.myPlayerNum == 1 && app.playerStanding_TS > 21) || ...
                     (app.myPlayerNum == 2 && app.dealerStanding_TS > 21);

            if busted
                app.MessageLabel.Text = 'You busted! Sending state...';
                drawnow;
                app.SendDataToOtherPlayer(); 
                app.determineRoundWinner(app.playerStanding_TS, app.dealerStanding_TS); 
            else
                app.MessageLabel.Text = 'Score updated. Sending state...';
                drawnow;
                app.SendDataToOtherPlayer(); 
                app.MessageLabel.Text = 'Your turn. Hit or Stand.';
                app.setControlsEnabled(true); 
            end
            drawnow;
       
        end

        % Button pushed function: StandButton
        function StandButtonPushed(app, event)
            app.playSoundEffect(app.audioClickPlayer);
            if app.gameEnded || app.overallGameEnded || app.myPlayerNum ~= app.whoseTurn
                return; 
            end

            app.setControlsEnabled(false); 
            app.MessageLabel.Text = 'You stood. Sending state... Please wait.';
            drawnow;
            
            app.action = 0; 
            if app.myPlayerNum == 1
                app.playerStood = true;
            else 
                app.dealerStood = true;
            end

            
            if app.whoseTurn == 1
                app.whoseTurn = 2;
            else
                app.whoseTurn = 1;
            end
            
            app.SendDataToOtherPlayer(); 
            
            
            if (app.playerStood && app.dealerStood)
                app.MessageLabel.Text = 'Both players stood. Determining winner...';
                drawnow;
                app.determineRoundWinner(app.playerStanding_TS, app.dealerStanding_TS);
            else
                app.MessageLabel.Text = 'You stood. Waiting for other player...';
                drawnow;
                app.WaitForOtherPlayer(); 
            end
        end

        % Button pushed function: NewRoundButton
        function NewRoundButtonPushed(app, event)
            app.startNewRound();
        end

        % Button pushed function: NewGameButton
        function NewGameButtonPushed(app, event)
            app.resetGame();
        end
    end

    % Component initialization
    methods (Access = private)

        % Create UIFigure and components
        function createComponents(app)

            % Get the file path for locating images
            pathToMLAPP = fileparts(mfilename('fullpath'));

            % Create UIFigure and hide until all components are created
            app.UIFigure = uifigure('Visible', 'off');
            app.UIFigure.Color = [0.4667 0.6745 0.1882];
            app.UIFigure.Position = [100 100 640 480];
            app.UIFigure.Name = 'MATLAB App';

            % Create HitButton
            app.HitButton = uibutton(app.UIFigure, 'push');
            app.HitButton.ButtonPushedFcn = createCallbackFcn(app, @HitButtonPushed, true);
            app.HitButton.BackgroundColor = [0.149 0.149 0.149];
            app.HitButton.FontColor = [1 1 1];
            app.HitButton.Position = [178 85 100 22];
            app.HitButton.Text = 'Hit';

            % Create StandButton
            app.StandButton = uibutton(app.UIFigure, 'push');
            app.StandButton.ButtonPushedFcn = createCallbackFcn(app, @StandButtonPushed, true);
            app.StandButton.BackgroundColor = [0 0 0];
            app.StandButton.FontColor = [1 1 1];
            app.StandButton.Position = [327 85 100 22];
            app.StandButton.Text = 'Stand';

            % Create RoleButtonGroup
            app.RoleButtonGroup = uibuttongroup(app.UIFigure);
            app.RoleButtonGroup.ForegroundColor = [1 1 1];
            app.RoleButtonGroup.Title = 'Role';
            app.RoleButtonGroup.BackgroundColor = [0.149 0.149 0.149];
            app.RoleButtonGroup.Position = [475 362 123 77];

            % Create PlayerButton
            app.PlayerButton = uiradiobutton(app.RoleButtonGroup);
            app.PlayerButton.Text = 'Player';
            app.PlayerButton.FontColor = [1 1 1];
            app.PlayerButton.Position = [11 31 58 22];
            app.PlayerButton.Value = true;

            % Create DealerButton
            app.DealerButton = uiradiobutton(app.RoleButtonGroup);
            app.DealerButton.Text = 'Dealer';
            app.DealerButton.FontColor = [1 1 1];
            app.DealerButton.Position = [11 9 65 22];

            % Create StartButton
            app.StartButton = uibutton(app.UIFigure, 'push');
            app.StartButton.ButtonPushedFcn = createCallbackFcn(app, @StartButtonPushed, true);
            app.StartButton.BackgroundColor = [0.149 0.149 0.149];
            app.StartButton.FontColor = [1 1 1];
            app.StartButton.Position = [487 325 100 22];
            app.StartButton.Text = 'Start';

            % Create DiceValueButtonGroup
            app.DiceValueButtonGroup = uibuttongroup(app.UIFigure);
            app.DiceValueButtonGroup.BorderColor = [0.502 0.502 0.502];
            app.DiceValueButtonGroup.ForegroundColor = [1 1 1];
            app.DiceValueButtonGroup.HighlightColor = [0.502 0.502 0.502];
            app.DiceValueButtonGroup.Title = 'Dice Value';
            app.DiceValueButtonGroup.BackgroundColor = [0.149 0.149 0.149];
            app.DiceValueButtonGroup.Position = [475 173 123 106];

            % Create SumofDiceButton
            app.SumofDiceButton = uiradiobutton(app.DiceValueButtonGroup);
            app.SumofDiceButton.Text = 'Sum of Dice';
            app.SumofDiceButton.FontColor = [1 1 1];
            app.SumofDiceButton.Position = [11 60 87 22];
            app.SumofDiceButton.Value = true;

            % Create TopDiceButton
            app.TopDiceButton = uiradiobutton(app.DiceValueButtonGroup);
            app.TopDiceButton.Text = 'Top Dice';
            app.TopDiceButton.FontColor = [1 1 1];
            app.TopDiceButton.Position = [11 38 68 22];

            % Create BottomDiceButton
            app.BottomDiceButton = uiradiobutton(app.DiceValueButtonGroup);
            app.BottomDiceButton.Text = 'Bottom Dice';
            app.BottomDiceButton.FontColor = [1 1 1];
            app.BottomDiceButton.Position = [11 16 87 22];

            % Create SelectButton
            app.SelectButton = uibutton(app.UIFigure, 'push');
            app.SelectButton.ButtonPushedFcn = createCallbackFcn(app, @SelectButtonPushed, true);
            app.SelectButton.BackgroundColor = [0.149 0.149 0.149];
            app.SelectButton.FontColor = [1 1 1];
            app.SelectButton.Position = [487 141 100 22];
            app.SelectButton.Text = 'Select';

            % Create PlayerTotalEditFieldLabel
            app.PlayerTotalEditFieldLabel = uilabel(app.UIFigure);
            app.PlayerTotalEditFieldLabel.HorizontalAlignment = 'right';
            app.PlayerTotalEditFieldLabel.FontName = 'Calibri Light';
            app.PlayerTotalEditFieldLabel.FontSize = 14;
            app.PlayerTotalEditFieldLabel.FontWeight = 'bold';
            app.PlayerTotalEditFieldLabel.Position = [22 438 69 22];
            app.PlayerTotalEditFieldLabel.Text = 'Player Total';

            % Create PlayerTotalUI
            app.PlayerTotalUI = uieditfield(app.UIFigure, 'numeric');
            app.PlayerTotalUI.AllowEmpty = 'on';
            app.PlayerTotalUI.FontColor = [1 1 1];
            app.PlayerTotalUI.BackgroundColor = [0.149 0.149 0.149];
            app.PlayerTotalUI.Position = [106 438 100 22];

            % Create DealerTotalEditFieldLabel
            app.DealerTotalEditFieldLabel = uilabel(app.UIFigure);
            app.DealerTotalEditFieldLabel.HorizontalAlignment = 'right';
            app.DealerTotalEditFieldLabel.FontName = 'Calibri Light';
            app.DealerTotalEditFieldLabel.FontSize = 14;
            app.DealerTotalEditFieldLabel.FontWeight = 'bold';
            app.DealerTotalEditFieldLabel.Position = [19 393 72 22];
            app.DealerTotalEditFieldLabel.Text = 'Dealer Total';

            % Create DealerTotalUI
            app.DealerTotalUI = uieditfield(app.UIFigure, 'numeric');
            app.DealerTotalUI.AllowEmpty = 'on';
            app.DealerTotalUI.FontColor = [1 1 1];
            app.DealerTotalUI.BackgroundColor = [0.149 0.149 0.149];
            app.DealerTotalUI.Position = [106 393 100 22];

            % Create PlayerStandingEditFieldLabel
            app.PlayerStandingEditFieldLabel = uilabel(app.UIFigure);
            app.PlayerStandingEditFieldLabel.HorizontalAlignment = 'right';
            app.PlayerStandingEditFieldLabel.FontName = 'Calibri Light';
            app.PlayerStandingEditFieldLabel.FontSize = 14;
            app.PlayerStandingEditFieldLabel.FontWeight = 'bold';
            app.PlayerStandingEditFieldLabel.Position = [0 350 91 22];
            app.PlayerStandingEditFieldLabel.Text = 'Player Standing';

            % Create PlayerStandingUI
            app.PlayerStandingUI = uieditfield(app.UIFigure, 'numeric');
            app.PlayerStandingUI.AllowEmpty = 'on';
            app.PlayerStandingUI.FontColor = [1 1 1];
            app.PlayerStandingUI.BackgroundColor = [0.149 0.149 0.149];
            app.PlayerStandingUI.Position = [106 350 100 22];

            % Create DealerStandingEditFieldLabel
            app.DealerStandingEditFieldLabel = uilabel(app.UIFigure);
            app.DealerStandingEditFieldLabel.HorizontalAlignment = 'right';
            app.DealerStandingEditFieldLabel.FontName = 'Calibri Light';
            app.DealerStandingEditFieldLabel.FontSize = 14;
            app.DealerStandingEditFieldLabel.FontWeight = 'bold';
            app.DealerStandingEditFieldLabel.Position = [-3 304 94 22];
            app.DealerStandingEditFieldLabel.Text = 'Dealer Standing';

            % Create DealerStandingUI
            app.DealerStandingUI = uieditfield(app.UIFigure, 'numeric');
            app.DealerStandingUI.AllowEmpty = 'on';
            app.DealerStandingUI.FontColor = [1 1 1];
            app.DealerStandingUI.BackgroundColor = [0.149 0.149 0.149];
            app.DealerStandingUI.Position = [106 304 100 22];

            % Create NewGameButton
            app.NewGameButton = uibutton(app.UIFigure, 'push');
            app.NewGameButton.ButtonPushedFcn = createCallbackFcn(app, @NewGameButtonPushed, true);
            app.NewGameButton.BackgroundColor = [0 0 0];
            app.NewGameButton.FontColor = [1 1 1];
            app.NewGameButton.Position = [53 230 100 22];
            app.NewGameButton.Text = 'New Game';

            % Create NewRoundButton
            app.NewRoundButton = uibutton(app.UIFigure, 'push');
            app.NewRoundButton.ButtonPushedFcn = createCallbackFcn(app, @NewRoundButtonPushed, true);
            app.NewRoundButton.BackgroundColor = [0.149 0.149 0.149];
            app.NewRoundButton.FontColor = [1 1 1];
            app.NewRoundButton.Position = [54 168 100 22];
            app.NewRoundButton.Text = 'New Round';

            % Create Dice1Label
            app.Dice1Label = uilabel(app.UIFigure);
            app.Dice1Label.Position = [308 362 36 22];
            app.Dice1Label.Text = 'Dice1';

            % Create Dice2Label
            app.Dice2Label = uilabel(app.UIFigure);
            app.Dice2Label.Position = [308 233 36 22];
            app.Dice2Label.Text = 'Dice2';

            % Create MessageLabel
            app.MessageLabel = uilabel(app.UIFigure);
            app.MessageLabel.FontName = 'Calibri Light';
            app.MessageLabel.FontWeight = 'bold';
            app.MessageLabel.Position = [235 373 162 63];
            app.MessageLabel.Text = 'Messages';

            % Create RoundWinnerLabel
            app.RoundWinnerLabel = uilabel(app.UIFigure);
            app.RoundWinnerLabel.FontName = 'Calibri Light';
            app.RoundWinnerLabel.FontSize = 16;
            app.RoundWinnerLabel.FontWeight = 'bold';
            app.RoundWinnerLabel.Position = [277 438 98 22];
            app.RoundWinnerLabel.Text = 'Round Winner';

            % Create dice1_1
            app.dice1_1 = uiimage(app.UIFigure);
            app.dice1_1.Position = [277 265 100 100];
            app.dice1_1.ImageSource = fullfile(pathToMLAPP, 'diceImages', 'dice1.png');

            % Create dice1_2
            app.dice1_2 = uiimage(app.UIFigure);
            app.dice1_2.Position = [277 265 100 100];
            app.dice1_2.ImageSource = fullfile(pathToMLAPP, 'diceImages', 'dice2.png');

            % Create dice1_3
            app.dice1_3 = uiimage(app.UIFigure);
            app.dice1_3.Position = [277 263 100 100];
            app.dice1_3.ImageSource = fullfile(pathToMLAPP, 'diceImages', 'dice3.png');

            % Create dice1_4
            app.dice1_4 = uiimage(app.UIFigure);
            app.dice1_4.Position = [277 263 100 100];
            app.dice1_4.ImageSource = fullfile(pathToMLAPP, 'diceImages', 'dice4.png');

            % Create dice1_5
            app.dice1_5 = uiimage(app.UIFigure);
            app.dice1_5.Position = [277 265 100 100];
            app.dice1_5.ImageSource = fullfile(pathToMLAPP, 'diceImages', 'dice5.png');

            % Create dice1_6
            app.dice1_6 = uiimage(app.UIFigure);
            app.dice1_6.Position = [277 265 100 100];
            app.dice1_6.ImageSource = fullfile(pathToMLAPP, 'diceImages', 'dice6.png');

            % Create dice2_1
            app.dice2_1 = uiimage(app.UIFigure);
            app.dice2_1.Position = [277 134 100 100];
            app.dice2_1.ImageSource = fullfile(pathToMLAPP, 'diceImages', 'dice1.png');

            % Create dice2_2
            app.dice2_2 = uiimage(app.UIFigure);
            app.dice2_2.Position = [277 134 100 100];
            app.dice2_2.ImageSource = fullfile(pathToMLAPP, 'diceImages', 'dice2.png');

            % Create dice2_3
            app.dice2_3 = uiimage(app.UIFigure);
            app.dice2_3.Position = [276 134 100 100];
            app.dice2_3.ImageSource = fullfile(pathToMLAPP, 'diceImages', 'dice3.png');

            % Create dice2_4
            app.dice2_4 = uiimage(app.UIFigure);
            app.dice2_4.Position = [277 134 100 100];
            app.dice2_4.ImageSource = fullfile(pathToMLAPP, 'diceImages', 'dice4.png');

            % Create dice2_5
            app.dice2_5 = uiimage(app.UIFigure);
            app.dice2_5.Position = [276 134 100 100];
            app.dice2_5.ImageSource = fullfile(pathToMLAPP, 'diceImages', 'dice5.png');

            % Create dice2_6
            app.dice2_6 = uiimage(app.UIFigure);
            app.dice2_6.Position = [276 134 100 100];
            app.dice2_6.ImageSource = fullfile(pathToMLAPP, 'diceImages', 'dice6.png');

            % Show the figure after all components are created
            app.UIFigure.Visible = 'on';
        end
    end

    % App creation and deletion
    methods (Access = public)

        % Construct app
        function app = DiceGameENG6Core

            % Create UIFigure and components
            createComponents(app)

            % Register the app with App Designer
            registerApp(app, app.UIFigure)

            % Execute the startup function
            runStartupFcn(app, @startupFcn)

            if nargout == 0
                clear app
            end
        end

        % Code that executes before app deletion
        function delete(app)

            % Delete UIFigure when app is deleted
            delete(app.UIFigure)
        end
    end
end